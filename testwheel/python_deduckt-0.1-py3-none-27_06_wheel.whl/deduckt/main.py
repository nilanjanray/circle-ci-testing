from __future__ import absolute_import
from .deduckt import main
if __name__ == '__main__':
    #import deduckt
    #deduckt.main()
    pass
